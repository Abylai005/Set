package com.example.SimpleCRUDApplication;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SimpleCrudApplicationTests {

	@Test
	void contextLoads() {
	}

}
